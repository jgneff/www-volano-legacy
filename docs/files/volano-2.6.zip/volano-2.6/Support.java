import java.applet.*;
import java.awt.*;
import java.util.*;

public class Support extends Applet {
    private static final String[] keys = {
        "java.class.version",
        "java.specification.name",
        "java.specification.vendor",
        "java.specification.version",
        "java.vendor",
        "java.vendor.url",
        "java.version",
        "java.vm.name",
        "java.vm.specification.name",
        "java.vm.specification.vendor",
        "java.vm.specification.version",
        "java.vm.vendor",
        "java.vm.version",
        "os.arch",
        "os.name",
        "os.version",
    };

    private TextArea area;

    public void init() {
        area = new TextArea();
        setLayout(new BorderLayout());
        add("Center", area);
    }

    public void start() {
        for (int i = 0; i < keys.length; i++) {
            area.append(keys[i] + " = ");
            try {
                area.append(System.getProperty(keys[i]));
            }
            catch (SecurityException e) {}
            area.append("\n");
        }
    }

    public void stop() {
        area.setText("");
    }
}
