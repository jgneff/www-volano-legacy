import java.applet.*;
import java.awt.*;
import java.text.*;
import java.util.*;

public class formats extends Applet {
  private static final String KEY_TYPE      = "type";
  private static final String VALUE_SERVER  = "server";
  private static final String VALUE_PUBLIC  = "public";
  private static final String VALUE_PRIVATE = "private";
  private static final String VALUE_STATUS  = "status";

  private static final int    SERVER  = 0;
  private static final int    PUBLIC  = 1;
  private static final int    PRIVATE = 2;
  private static final int    STATUS  = 3;

  private static final String FONT_NAME  = "Monospaced";
  private static final int    FONT_SIZE  = 12;
  private static final int    FIELD_SIZE = 50;
  private static final int    INSET      =  2;

  // Server access log patterns and sample values.

  // Sun 1.4.1
  //   192.168.0.1 - - [29/Oct/2002:12:45:18 CET] "GET http://www.volano.com/vcclient/ HTTP/2.5.0.1-BBBF1FE6" 200 1549 "http://www.volano.com/chat.html" "Sun Microsystems Inc./1.4.1 API/48.0 (Windows 2000/5.0 x86) http://java.sun.com/" 140 192.168.0.2
  // Microsoft 5.00.3805
  //   192.168.0.1 - - [29/Oct/2002:12:45:30 GMT+01:00] "GET http://www.volano.com/vcclient/ HTTP/2.5.0.1-BBBF1FE6" 200 1549 "http://www.volano.com/chat.html" "Microsoft Corp./1.1.4 API/45.3 (Windows NT/5.0 x86) http://www.microsoft.com/" 140 192.168.0.2
  // All extra variables:
  //   192.168.0.1 - - [29/Oct/2002:12:51:42 CET] "GET http://www.volano.com/vcclient/ HTTP/2.5.0.1-BBBF1FE6" 200 1549 "http://www.volano.com/chat.html" "Sun Microsystems Inc./1.4.1 API/48.0 (Windows 2000/5.0 x86) http://java.sun.com/" 140 www.volano.com www.volano.com 130 23 7 192.168.0.2

  private static final String DATE_PATTERN   = "[dd/MMM/yyyy:HH:mm:ss z]";
  private static final String AGENT_PATTERN  = "{0}/{1} API/{2} ({3}/{4} {5}) {6}";
  private static final String EXTRA_PATTERN  = "{0,number,0} {6}";
  private static final String SERVER_PATTERN = "{0} - - {1} \"GET {2} HTTP/{3}\" {4,number,0} {5,number,0} \"{6}\" \"{7}\" {8}";
  private Object[] agentArgs = {
    System.getProperty("java.vendor",        ""),
    System.getProperty("java.version",       ""),
    System.getProperty("java.class.version", ""),
    System.getProperty("os.name",            ""),
    System.getProperty("os.version",         ""),
    System.getProperty("os.arch",            ""),
    System.getProperty("java.vendor.url",    "")
  };
  private Object[] extraArgs  = {new Integer(140), "www.volano.com", "www.volano.com", new Integer(130), new Integer(23), new Integer(7), "192.168.0.2"};
  private Object[] serverArgs = {"192.168.0.1", "", "http://www.volano.com/vcclient/", "2.5.0.1-BBBF1FE6", new Integer(200), new Integer(1549), "http://www.volano.com/chat.html", "", ""};

  // Public room access log patterns and sample values.

  // Sun 1.4.1
  //   [29/Oct/2002:12:47:39 CET] 13 "Get Java Now!" "Mark" 192.168.0.1
  // Microsoft 5.00.3805
  //   [29/Oct/2002:12:48:20 GMT+01:00] 13 "Get Java Now!" "Mark" 192.168.0.1

  private static final String PUBLIC_PATTERN = "{0} {1,number,0} \"{2}\" \"{3}\" {4}";
  private Object[] publicArgs = {"", new Integer(13), "Get Java Now!", "Mark", "192.168.0.1"};

  // Private room access log patterns and sample values.

  // Sun 1.4.1
  //   [29/Oct/2002:12:40:54 CET] 2138 "Truth or Dare!" "Archie" 192.168.0.1 "pomy" 192.168.0.2
  // Microsoft 5.00.3805
  //   [29/Oct/2002:12:49:14 GMT+01:00] 2138 "Truth or Dare!" "Archie" 192.168.0.1 "pomy" 192.168.0.2

  private static final String PRIVATE_PATTERN = "{0} {1,number,0} \"{2}\" \"{3}\" {4} \"{5}\" {6}";
  private Object[] privateArgs = {"", new Integer(2138), "Truth or Dare!", "Archie", "192.168.0.1", "pomy", "192.168.0.2"};

  // To do -- add the banned log and chat message log formatting.
  String FORMAT_BANNED       = "{1}={2,choice,0#Static|1#Dynamic|2#Netblock} address banned at {0} as {4} in {3} by {5}";
  String FORMAT_CHAT_PUBLIC  = "{3,date,[dd/MMM/yyyy:HH:mm:ss]} <b>&lt;{0}&gt;</b> {2}<br>";
  String FORMAT_CHAT_PRIVATE = "{3,date,[dd/MMM/yyyy:HH:mm:ss]} <b>&lt;{0} -&gt; {1}&gt;</b> {2}<br>";

  // Status report patterns and sample values.

  // Sun 1.4.1
  //   [29/Oct/2002:12:40:55 CET] 2105KB/3176KB 66% 130 46 (46) 23 0 11 1 12 13
  // Microsoft 5.00.3805
  //   [29/Oct/2002:12:39:58 GMT+01:00] 2105KB/3176KB 66% 130 46 (46) 23 0 11 1 12 13

  private static final String MEMORY_PATTERN   = "{0,number,0}KB/{1,number,0}KB {2,number,0%}";
  private static final String RESOURCE_PATTERN = "{0,number,0} {1,number,0} ({2,number,0})";
  private static final String STATUS_PATTERN   = "{0} {1} {2} {3,number,0} {4,number,0} {5,number,0} {6,number,0} {7,number,0} {8,number,0}";
  private Object[] memoryArgs   = {new Integer(2105), new Integer(3176), new Float(0.66f)};
  private Object[] resourceArgs = {new Integer(130), new Integer(46), new Integer(46)};
  private Object[] statusArgs   = {"", "", "", new Integer(23), new Integer(0), new Integer(11),
                                               new Integer(1), new Integer(12), new Integer(13)};

  private int       type;		// SERVER, PUBLIC, or PRIVATE
  private String    pattern;		// Default access pattern
  private Object[]  arguments;		// Default access arguments

  private Label     dateLabel;
  private TextField dateField;
  private TextField dateOutput;

  private Label     agentLabel;
  private TextField agentField;
  private TextField agentOutput;

  private Label     extraLabel;
  private TextField extraField;
  private TextField extraOutput;

  private Label     memoryLabel;
  private TextField memoryField;
  private TextField memoryOutput;

  private Label     resourceLabel;
  private TextField resourceField;
  private TextField resourceOutput;

  private Label     accessLabel;
  private TextField accessField;
  private TextField accessOutput;

  private Button    resetButton;
  private Button    formatButton;

  public void init() {
    type = getType();

    String label;
    if (type == PUBLIC) {
      label     = "format.public =";
      pattern   = PUBLIC_PATTERN;
      arguments = publicArgs;
    }
    else if (type == PRIVATE) {
      label     = "format.private =";
      pattern   = PRIVATE_PATTERN;
      arguments = privateArgs;
    }
    else if (type == STATUS) {
      label     = "format.status =";
      pattern   = STATUS_PATTERN;
      arguments = statusArgs;
    }
    else {
      label     = "format.access =";
      pattern   = SERVER_PATTERN;
      arguments = serverArgs;
    }

    Font font = new Font(FONT_NAME, Font.PLAIN, FONT_SIZE);
    setBackground(Color.white);

    GridBagLayout      layout      = new GridBagLayout();
    GridBagConstraints constraints = new GridBagConstraints();
    constraints.insets = new Insets(INSET, INSET, INSET, INSET);
    setLayout(layout);

    constraints.gridy  = 0;
    constraints.fill   = GridBagConstraints.NONE;
    constraints.anchor = GridBagConstraints.EAST;
    dateLabel = new Label("format.date =", Label.RIGHT);
    layout.setConstraints(dateLabel, constraints);
    add(dateLabel);

    constraints.fill   = GridBagConstraints.HORIZONTAL;
    constraints.anchor = GridBagConstraints.WEST;
    dateField = new TextField(DATE_PATTERN, FIELD_SIZE);
    dateField.setFont(font);
    layout.setConstraints(dateField, constraints);
    add(dateField);

    constraints.gridx = 1;
    constraints.gridy = 1;
    dateOutput = new TextField(FIELD_SIZE);
    dateOutput.setFont(font);
    dateOutput.setEditable(false);
    layout.setConstraints(dateOutput, constraints);
    add(dateOutput);

    if (type == SERVER) {
      constraints.gridx  = GridBagConstraints.RELATIVE;
      constraints.gridy  = 2;
      constraints.fill   = GridBagConstraints.NONE;
      constraints.anchor = GridBagConstraints.EAST;
      agentLabel = new Label("format.access.agent =", Label.RIGHT);
      layout.setConstraints(agentLabel, constraints);
      add(agentLabel);

      constraints.fill   = GridBagConstraints.HORIZONTAL;
      constraints.anchor = GridBagConstraints.WEST;
      agentField = new TextField(AGENT_PATTERN, FIELD_SIZE);
      agentField.setFont(font);
      layout.setConstraints(agentField, constraints);
      add(agentField);

      constraints.gridx = 1;
      constraints.gridy = 3;
      agentOutput = new TextField(FIELD_SIZE);
      agentOutput.setFont(font);
      agentOutput.setEditable(false);
      layout.setConstraints(agentOutput, constraints);
      add(agentOutput);

      constraints.gridx  = GridBagConstraints.RELATIVE;
      constraints.gridy  = 4;
      constraints.fill   = GridBagConstraints.NONE;
      constraints.anchor = GridBagConstraints.EAST;
      extraLabel = new Label("format.access.extra =", Label.RIGHT);
      layout.setConstraints(extraLabel, constraints);
      add(extraLabel);

      constraints.fill   = GridBagConstraints.HORIZONTAL;
      constraints.anchor = GridBagConstraints.WEST;
      extraField = new TextField(EXTRA_PATTERN, FIELD_SIZE);
      extraField.setFont(font);
      layout.setConstraints(extraField, constraints);
      add(extraField);

      constraints.gridx = 1;
      constraints.gridy = 5;
      extraOutput = new TextField(FIELD_SIZE);
      extraOutput.setFont(font);
      extraOutput.setEditable(false);
      layout.setConstraints(extraOutput, constraints);
      add(extraOutput);
    }
    else if (type == STATUS) {
      constraints.gridx  = GridBagConstraints.RELATIVE;
      constraints.gridy  = 2;
      constraints.fill   = GridBagConstraints.NONE;
      constraints.anchor = GridBagConstraints.EAST;
      memoryLabel = new Label("format.status.memory =", Label.RIGHT);
      layout.setConstraints(memoryLabel, constraints);
      add(memoryLabel);

      constraints.fill   = GridBagConstraints.HORIZONTAL;
      constraints.anchor = GridBagConstraints.WEST;
      memoryField = new TextField(MEMORY_PATTERN, FIELD_SIZE);
      memoryField.setFont(font);
      layout.setConstraints(memoryField, constraints);
      add(memoryField);

      constraints.gridx = 1;
      constraints.gridy = 3;
      memoryOutput = new TextField(FIELD_SIZE);
      memoryOutput.setFont(font);
      memoryOutput.setEditable(false);
      layout.setConstraints(memoryOutput, constraints);
      add(memoryOutput);

      constraints.gridx  = GridBagConstraints.RELATIVE;
      constraints.gridy  = 4;
      constraints.fill   = GridBagConstraints.NONE;
      constraints.anchor = GridBagConstraints.EAST;
      resourceLabel = new Label("format.status.resources =", Label.RIGHT);
      layout.setConstraints(resourceLabel, constraints);
      add(resourceLabel);

      constraints.fill   = GridBagConstraints.HORIZONTAL;
      constraints.anchor = GridBagConstraints.WEST;
      resourceField = new TextField(RESOURCE_PATTERN, FIELD_SIZE);
      resourceField.setFont(font);
      layout.setConstraints(resourceField, constraints);
      add(resourceField);

      constraints.gridx = 1;
      constraints.gridy = 5;
      resourceOutput = new TextField(FIELD_SIZE);
      resourceOutput.setFont(font);
      resourceOutput.setEditable(false);
      layout.setConstraints(resourceOutput, constraints);
      add(resourceOutput);
    }

    constraints.gridx  = GridBagConstraints.RELATIVE;
    constraints.gridy  = type == SERVER ? 6 : (type == STATUS ? 6 : 2);
    constraints.fill   = GridBagConstraints.NONE;
    constraints.anchor = GridBagConstraints.EAST;
    accessLabel = new Label(label, Label.RIGHT);
    layout.setConstraints(accessLabel, constraints);
    add(accessLabel);

    constraints.fill   = GridBagConstraints.HORIZONTAL;
    constraints.anchor = GridBagConstraints.WEST;
    accessField = new TextField(pattern, FIELD_SIZE);
    accessField.setFont(font);
    layout.setConstraints(accessField, constraints);
    add(accessField);

    constraints.gridy     = type == SERVER ? 7 : (type == STATUS ? 7 : 3);
    constraints.gridwidth = 2;
    accessOutput = new TextField(FIELD_SIZE);
    accessOutput.setFont(font);
    accessOutput.setEditable(false);
    layout.setConstraints(accessOutput, constraints);
    add(accessOutput);

    constraints.gridy = type == SERVER ? 8 : (type == STATUS ? 8 : 4);
    Panel panel = new Panel();
    panel.setLayout(new FlowLayout(FlowLayout.RIGHT));
    resetButton = new Button("Reset");
    formatButton = new Button("Format");
    panel.add(resetButton);
    panel.add(formatButton);
    layout.setConstraints(panel, constraints);
    add(panel);

    format();
  }

  public boolean action(Event event, Object object) {
    if (event.target == dateField || event.target == accessField ||
        event.target == agentField || event.target == extraField ||
        event.target == memoryField || event.target == resourceField ||
        event.target == formatButton) {
      format();
      return true;
    }
    else if (event.target == resetButton) {
      reset();
      format();
      return true;
    }
    return false;
  }

  private int getType() {
    String value = getParameter(KEY_TYPE);
    if (value == null)
      return SERVER;
    value = value.trim().toLowerCase();
    if (value.equals(VALUE_PUBLIC))
      return PUBLIC;
    else if (value.equals(VALUE_PRIVATE))
      return PRIVATE;
    else if (value.equals(VALUE_STATUS))
      return STATUS;
    else
      return SERVER;
  }

  private void reset() {
    dateField.setText(DATE_PATTERN);
    accessField.setText(pattern);
    if (type == SERVER) {
      agentField.setText(AGENT_PATTERN);
      extraField.setText(EXTRA_PATTERN);
    }
    else if (type == STATUS) {
      memoryField.setText(MEMORY_PATTERN);
      resourceField.setText(RESOURCE_PATTERN);
    }
  }

  private void format() {
    TextField error = dateOutput;
    try {
      DateFormat dateFormatter = new SimpleDateFormat(dateField.getText());
      dateFormatter.setTimeZone(TimeZone.getDefault());
      String date = dateFormatter.format(new Date());
      dateOutput.setForeground(Color.black);
      dateOutput.setText((String) date);

      if (type == SERVER) {
        error = agentOutput;
        serverArgs[7] = MessageFormat.format(agentField.getText(), agentArgs);
        agentOutput.setForeground(Color.black);
        agentOutput.setText((String) serverArgs[7]);

        error = extraOutput;
        serverArgs[8] = MessageFormat.format(extraField.getText(), extraArgs);
        extraOutput.setForeground(Color.black);
        extraOutput.setText((String) serverArgs[8]);
      }
      else if (type == STATUS) {
        error = memoryOutput;
        statusArgs[1] = MessageFormat.format(memoryField.getText(), memoryArgs);
        memoryOutput.setForeground(Color.black);
        memoryOutput.setText((String) statusArgs[1]);
        statusArgs[2] = MessageFormat.format(resourceField.getText(), resourceArgs);
        resourceOutput.setForeground(Color.black);
        resourceOutput.setText((String) statusArgs[2]);
      }

      if (type == SERVER)
        arguments[1] = date;
      else
        arguments[0] = date;
      error = accessOutput;
      accessOutput.setForeground(Color.black);
      accessOutput.setText(MessageFormat.format(accessField.getText(), arguments));
    }
    catch (Throwable t) {
      error.setForeground(Color.red);
      error.setText(t.toString());
    }
  }
}
