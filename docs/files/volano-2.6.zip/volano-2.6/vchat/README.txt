VOLANOCHAT(TM) AND VOLANOCHATPRO(TM)

You may read this file after installation by opening the file
"README.txt" in the location where you installed VolanoChat.

Read the Volano Software License Agreement before completing the
installation of this program. After installation, you'll find the
License Agreement as the file "LICENSE.txt" in the location where you
installed VolanoChat. If you do not agree to the terms, return the
program for a prompt refund. If you install this program we will assume
you have read, understood, and agreed to our warranty terms.

To uninstall VolanoChat, simply run "java uninstall" from the location
where you installed VolanoChat. For setup instructions, please continue
with the VolanoChat Administrator Guide at:

  http://www.volano.com/documentation.html

Send any comments, questions, or bug reports to:

  mailto:support@volano.com

Volano LLC
126 SW 148th Street Suite C100 PMB 28
Burien WA  98166-1984
USA

206-575-9379 (voice)
909-498-9986 (fax)
http://www.volano.com/
mailto:support@volano.com
