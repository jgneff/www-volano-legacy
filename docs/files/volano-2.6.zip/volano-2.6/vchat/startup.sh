#!/bin/sh
#*****************************************************************************
# Sample Bourne Shell script for starting the VolanoChat server.
# Specify the "-h" option for help.
#*****************************************************************************

if [ "$1" = "-h" ]
then
    echo "Usage: $0 [-h] [-r] [file]"
    echo "Start the VolanoChat server.  The default is to start the server"
    echo "once and load its properties from the file \"conf/properties.txt\"."
    echo "  -h    display this help information."
    echo "  -r    restart the server if it stops."
    echo "  file  the location of the server properties file."
    exit
fi

# Define the Java system properties and class path.
properties="-Dinstall.root=. -Dcatalina.home=."
classpath=.

# Define any settings specific to each operating system.
os=`uname -s`
case $os in

    CYGWIN*)    # Microsoft Windows with Cygwin
        for file in lib/*.jar; do classpath="$classpath;$file"; done
        java=/cygdrive/c/jdk1.3.1_13/bin/java
        options="-server -Xmx256m -Xss128k"
        ;;

    Darwin)     # Apple Mac OS X
        ulimit -n 1024
        for file in lib/*.jar; do classpath="$classpath:$file"; done
        java=/usr/bin/java
        options="-server -Xmx256m -Xss128k"
        ;;

    FreeBSD)    # FreeBSD
        ulimit -n 1024
        for file in lib/*.jar; do classpath="$classpath:$file"; done
        java=/usr/local/j2sdk1.3.1/bin/java
        options="-green -Xmx256m -Xss128k"
        ;;

    Linux)      # GNU/Linux
        ulimit -n 1024
        for file in lib/*.jar; do classpath="$classpath:$file"; done

        # For the Blackdown Java 2 Classic VM, use these variables:
        java=/usr/local/j2sdk1.3.1/bin/java
        options="-green -Xmx256m -Xss128k"

        # For the Sun Java 2 HotSpot Server VM, use these variables:
        # java=/usr/java/j2sdk1.4.2_05/bin/java
        # options="-server -Xmx256m -Xss128k"
        ;;

    SunOS)      # Sun Solaris
        ulimit -n 1024
        for file in lib/*.jar; do classpath="$classpath:$file"; done
        java=/usr/j2se/bin/java
        options="-server -Xmx256m -Xss128k"
        ;;

    *)          # Unknown operating system
        echo "Unrecognized operating system name: $os"
        exit
        ;;
esac

# Quit if we cannot find the Java executable file.
if [ ! -x "$java" ]
then
    echo "Java virtual machine not found: $java"
    exit
fi

# Print the Java version.
$java $options -version

# Start the VolanoChat server.
# The "-r" option specifies to restart the server if it terminates.
if [ "$1" = "-r" ]
then
    while :
    do
        echo "[`date`] Starting server ..."
        $java $options $properties -cp $classpath COM.volano.Main $2
        code=$?
        echo "[`date`] Server terminated with exit code $code."
        sleep 15
    done
else
    $java $options $properties -cp $classpath COM.volano.Main $1
fi
