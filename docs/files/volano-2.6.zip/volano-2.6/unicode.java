import java.applet.*;
import java.awt.*;

public class unicode extends Applet {
  private static final Font FONT   = new Font("TimesRoman", Font.PLAIN, 15);
  private static final int  COUNT  =  7;	// Count of strings
  private static final int  LENGTH = 10;	// Length of strings

  private String[] name    = {"Latin",  "Greek",  "Cyrillic", "Hebrew", "Arabic", "Katakana", "CJK"};
  private char[]   start   = {'\u0041', '\u0391', '\u0410',   '\u05d0', '\u0621', '\u30a1',   '\u3300'};
  private char[]   string  = new char[LENGTH];
  private String[] element = new String[COUNT];
  private List     nameList;
  private List     fontList;

  public void init() {
    for (int i = 0; i < COUNT; i++) {
      string[0] = start[i];
      for (int j = 1; j < LENGTH; j++)
        string[j] = (char) (string[j - 1] + 1);
      element[i] = new String(string);
    }
    setLayout(new BorderLayout());
    nameList = new List(COUNT, false);
    fontList = new List(COUNT, false);
    nameList.setFont(FONT);
    fontList.setFont(FONT);
    add("West",   nameList);
    add("Center", fontList);
  }

  public void start() {
    nameList.clear();
    fontList.clear();
    for (int i = 0; i < COUNT; i++) {
      nameList.addItem(name[i]);
      fontList.addItem(element[i]);
    }
  }
}
