VOLANO(TM) Chat Server

Read the License Agreement before completing the installation of this
program. After installation, you will find the License Agreement as
the file "LICENSE.txt" in the location where you installed the VOLANO
Chat Server. If you do not agree to the terms, return the program for
a prompt refund. If you install this program, we will assume you have
read, understood, and agreed to our warranty terms.

Send any comments, questions, or bug reports to:

  John Neffenger <john@status6.com>

Status Six Communications
125A-1030 Denman Street
Vancouver BC  V6G 2M6
Canada
